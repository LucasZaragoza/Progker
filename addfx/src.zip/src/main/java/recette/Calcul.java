package recette;

import java.util.LinkedList;
import java.util.Random;

public class Calcul {

	public static String calcul(double qte, int nbPers, int niveau, int numIngredient) {
		int res = (int) (qte * nbPers);
		switch (niveau) {
		case 0:
			return niveau0(res);
		case 1:
			return niveau1(res);
		case 2:
			return niveau2(res);
		case 3:
			return niveau3(res);
		case 4:
			return niveau4(res);
		case 5:
			return niveau5(res);
		default:
			return niveau6(res);
		}
	}
	
	
	/**
	 * opération que l'apprenant peut faire
	 * 
	 * * + - /
	 * opérations combinées
	 * 
	 * l'apprenant saisit le nb de crepes qu'il veut faire
	 * nbr de termes
	 * 
	 * niveau 0 : +		
	 * niveau 1 : -
	 *  2 : *
	 *  3 : /
	 *  4 : + ou - et * 3 termes
	 *  5 : + ou - et / 3 termes
	 *  6 : + - * / 4 termes
	 *  
	 */
	

	private static String niveau0(int res) {
		int membre1;
		int membre2;
		int cpt = 0;
		if (res == 1) {
			return myToString(1,0,"+",0);
		}
		if (multipleDix(res)) {
			membre1 = 1 + (int)(Math.random() * ((9 - 1) + 1));
			membre1 *= res / 10;
			//membre1 = random.nextInt((1+ res - 1)) + 1;
			membre2 = res - membre1;
			return myToString(membre1,membre2,"+");	
		}
		while(res%10 == 0) {
			cpt++;
			res = res/10;
		}
		//int nombreAleatoire = Min + (int)(Math.random() * ((Max - Min) + 1));
		membre1 = 1 + (int)(Math.random() * ((res-1 - 1) + 1));
		//membre1 = random.nextInt((1+ res - 1)) + 1;
		membre2 = res - membre1;
		return myToString(membre1,membre2,"+",cpt);		

	}

	
	private static boolean multipleDix(int tmp) {
		while (tmp > 9)
			tmp /= 10;
		return (tmp == 1);
	}


	private static String niveau1(int res) {
		int membre1;
		int membre2;

		//int nombreAleatoire = Min + (int)(Math.random() * ((Max - Min) + 1));
		membre1 = 1 + (int)(Math.random() * ((res-1 - 1) + 1));
		membre2 = res + membre1;
		return myToString(membre2, membre1, "-");
	}

	private static String niveau2(int res) {
		int membre1;
		int membre2;
		
		membre1 = diviseurAleatoire(res,2,11);
		
		//int nombreAleatoire = Min + (int)(Math.random() * ((Max - Min) + 1));
		membre2 = res / membre1;
		return myToString(membre1, membre2, "*");
	}
	
	
	
	private static String niveau3(int res) {
		int membre1;
		int membre2;

		//int nombreAleatoire = Min + (int)(Math.random() * ((Max - Min) + 1));	//min et max compris
		membre2 = 2 + (int)(Math.random() * ((5 - 2) + 1));
		membre1 = res*membre2;
		return myToString(membre1,membre2,"/");
	}
	
	
	private static String niveau4(int res) {
		int membre1;
		int membre2;
		
		membre1 = diviseurAleatoire(res,2,11);
		
		//int nombreAleatoire = Min + (int)(Math.random() * ((Max - Min) + 1));
		membre2 = res / membre1;
		String mbrString;
		if (membre1 > membre2) {	//mbr1 addition
			mbrString = niveau0ou1(membre1);
			return myToString("(" + mbrString + ")", membre2, "*");
		} else {
			mbrString = niveau0ou1(membre2);
			return myToString("(" + mbrString + ")", membre1, "*");
		}
		
	}
	
	private static String niveau5(int res) {
		int membre1;
		int membre2;
		
		membre2 = 2 + (int)(Math.random() * ((9 - 2) + 1));
		
		//int nombreAleatoire = Min + (int)(Math.random() * ((Max - Min) + 1));
		membre1 = res*membre2;
		String mbrString;
		if (membre1 > membre2) {	//mbr1 addition
			mbrString = niveau0ou1(membre1);
			return myToString("(" + mbrString + ")", membre2, "/");
		} else {
			mbrString = niveau0ou1(membre2);
			return myToString("(" + mbrString + ")", membre1, "/");
		}
	}

	private static String niveau6(int res) {
		int nbr = 1 + (int)(Math.random() * ((4 - 1) + 1));
		int [] mbrs;
		switch (nbr % 4) {
		case 0 :
			mbrs = niveau0bis(res);
			return "("+niveau012ou3(mbrs[0])+")" + " + " + "("+niveau012ou3(mbrs[1])+")";
		case 1 : 
			mbrs = niveau1bis(res);
			return "("+niveau012ou3(mbrs[1])+")" + " - " + "("+niveau012ou3(mbrs[0])+")";
		case 2 : 
			mbrs = niveau2bis(res);
			return "("+niveau012ou3(mbrs[0])+")" + " * " + "("+niveau012ou3(mbrs[1])+")";
		default:
			mbrs = niveau3bis(res);
			return "("+niveau012ou3(mbrs[0])+")" + " / " + "("+niveau012ou3(mbrs[1])+")";
		}
	}
	
	private static int[] niveau0bis(int res) {
		int membre1;
		int membre2;
		int cpt = 0;
		//int nombreAleatoire = Min + (int)(Math.random() * ((Max - Min) + 1));
		membre1 = 1 + (int)(Math.random() * ((res-1 - 1) + 1));
		//membre1 = random.nextInt((1+ res - 1)) + 1;
		membre2 = res - membre1;
		int[] aRet = new int[]{membre1, membre2};
		return aRet;		
	}
	
	private static int[] niveau1bis(int res) {
		int membre1;
		int membre2;

		//int nombreAleatoire = Min + (int)(Math.random() * ((Max - Min) + 1));
		membre1 = 1 + (int)(Math.random() * ((res-1 - 1) + 1));
		membre2 = res + membre1;
		int[] aRet = new int[]{membre1, membre2};
		return aRet;
	}

	private static int[] niveau2bis(int res) {
		int membre1;
		int membre2;
		
		membre1 = diviseurAleatoire(res,2,11);
		
		//int nombreAleatoire = Min + (int)(Math.random() * ((Max - Min) + 1));
		membre2 = res / membre1;
		int[] aRet = new int[]{membre1, membre2};
		return aRet;
	}
		
	private static int[] niveau3bis(int res) {
		int membre1;
		int membre2;

		//int nombreAleatoire = Min + (int)(Math.random() * ((Max - Min) + 1));	//min et max compris
		membre2 = 2 + (int)(Math.random() * ((5 - 2) + 1));
		membre1 = res*membre2;
		int[] aRet = new int[]{membre1, membre2};
		return aRet;
	}
	
	private static String niveau012ou3(int res) {
		int nbr = 1 + (int)(Math.random() * ((4 - 1) + 1));
		switch (nbr % 4) {
		case 0 :
			return niveau0ter(res);
		case 1 : 
			return niveau1(res);
		case 2 : 
			return niveau2(res);
		default:
			return niveau3(res);
		}
	}
	
	private static String niveau0ter(int res) {
		int membre1;
		int membre2;
		if(res==0) {
			return myToString(0, 0, "+");
		}
		//int nombreAleatoire = Min + (int)(Math.random() * ((Max - Min) + 1));
		membre1 = 1 + (int)(Math.random() * ((res-1 - 1) + 1));
		//membre1 = random.nextInt((1+ res - 1)) + 1;
		membre2 = res - membre1;
		return myToString(membre1,membre2,"+");		
	}
	
	private static String niveau0ou1(int membre1) {
		//int nombreAleatoire = Min + (int)(Math.random() * ((Max - Min) + 1));
		int nbr = 1 + (int)(Math.random() * ((2 - 1) + 1));
		if (nbr%2 == 0)
			return niveau0ter(membre1);
		else {
			return niveau1(membre1);
		}
	}
	
	private static int diviseurAleatoire(int res, int min, int max) {
		LinkedList<Integer> candidats = new LinkedList<Integer>();
		for (int i = min; i < max+1; i++)
			candidats.add(i);
		
		int ret = 0;
		Integer choix = 0;
		while(true){
			int size = candidats.size();
			if (size == 0) {
				ret = 1;
				break;
			}
			//int nombreAleatoire = Min + (int)(Math.random() * ((Max - Min) + 1));
			int item = (int)(Math.random() * ((size-1) + 1));
			choix = candidats.get(item);
			if (res % choix == 0 && res != choix) {
				ret = choix;
				break;
			}
			else {
				candidats.remove(choix);
			}
		}
		return ret;
	}
	
	
	private static String myToString(int membre1, int membre2, String string,int cpt) {
		String zero = "";
		for(int i = 0; i < cpt; i++)
			zero += "0";
		return Integer.toString(membre1) + zero + " " + string + " " + Integer.toString(membre2) + zero;
	}
	
	private static String myToString(int membre1, int membre2, String string) {
		return Integer.toString(membre1) + " " + string + " " + Integer.toString(membre2);
	}
	
	private static String myToString(String membre1, int membre2, String string) {
		return membre1 + " " + string + " " + Integer.toString(membre2);
	}
}
