package recette;

public class Ingredient {
	private float quantite;
	private String descr;
	
	public Ingredient(float a, String b) {
		quantite = a;
		descr = b;
	}

	public float getQuantite() {
		return quantite;
	}

	@Override
	public String toString() {
		return "Ingredient [quantite=" + quantite + ", descr=" + descr + "]";
	}

	public float getQte() {
		return quantite;
	}
	
	public String getDescription() {
		return descr;
	}
	
}
