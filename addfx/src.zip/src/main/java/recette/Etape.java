package recette;

public class Etape {
	String descrEtape;
	String [] nomPhoto;
	
	public Etape(String s,String string) {
		descrEtape = s;
		nomPhoto = new String[1];
		nomPhoto[0] = string;
	}

	public Etape(String s, String[] string) {
		descrEtape = s;
		nomPhoto = new String[string.length];
		for (int i = 0; i < string.length; i++) {
			nomPhoto[i] = string[i];
		}
	}

	public String getDescr() {
		return descrEtape;
	}
	public String[] getImg() {
		return nomPhoto;
	}
}
