package recette;

import java.io.FileNotFoundException;
import java.util.LinkedList;

public class BDDRecettes {
	private LinkedList<Recette> listeRecettes = new LinkedList<Recette>();
	private Recette recetteDuJour;

	public BDDRecettes() { // TODO argument difficulté
		recetteCrepes();
		recetteMoelleux();
		recette4_4();
		recetteCrumble();
		recetteTiramissu();
		recetteCookies();
		// choisi la recette du jour après avoir tout ajouté
		iniRecetteDuJour();
	}

	// ON CREE LES RECETTES POUR 1 PERSONNE
	
	private void recetteCrepes() {
		Recette crepes = new Recette();
		crepes.setNom("Pate à crepes");
		crepes.addIngredient(new Ingredient(100, " g de farine"));
		crepes.addIngredient(new Ingredient(1, " oeufs"));
		crepes.addIngredient(new Ingredient(1, " c.s de sucre"));
		crepes.addIngredient(new Ingredient(2, " c.s d'huile"));
		crepes.addIngredient(new Ingredient(15, " g de beurre"));
		crepes.addIngredient(new Ingredient(20, " cl de lait"));
		crepes.addEtape(new Etape("Mettez la farine dans un saladier avec le sel et le sucre.", new String[]{"farine","sel","sucre"}));
		crepes.addEtape(new Etape("Faites un puits au milieu et versez-y les œufs.","oeufs"));
		crepes.addEtape(new Etape(
				"Commencez à mélanger doucement. Quand le mélange devient épais, ajoutez le lait froid petit à petit.","lait"));
		crepes.addEtape(new Etape("Faites un puits au milieu et versez-y les œufs.","oeufs"));
		crepes.addEtape(new Etape(
				"Quand tout le lait est mélangé, la pâte doit être assez fluide. Si elle vous paraît trop épaisse, rajoutez un peu de lait. Ajoutez ensuite le beurre fondu refroidi, mélangez bien.",new String[]{"lait","beurre"}));
		crepes.addEtape(new Etape(
				"Faites cuire les crêpes dans une poêle chaude (par précaution légèrement huilée si votre poêle à crêpes n'est pas anti-adhésive). Versez une petite louche de pâte dans la poêle, faites un mouvement de rotation pour répartir la pâte sur toute la surface. Posez sur le feu et quand le tour de la crêpe se colore en roux clair, il est temps de la retourner.","crepe doree"));
		crepes.addEtape(new Etape("Laissez cuire environ une minute de ce côté et la crêpe est prête.","crepeF"));

		try {
			crepes.setImage("crepes");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		listeRecettes.add(crepes);
	}

	private void recetteMoelleux() {
		Recette moelleuxChoco = new Recette();
		moelleuxChoco.setNom("Moelleux");
		moelleuxChoco.addIngredient(new Ingredient(40, " g de chocolat"));
		moelleuxChoco.addIngredient(new Ingredient(20, " g de sucre glace"));
		moelleuxChoco.addIngredient(new Ingredient(12, " g de farine"));
		moelleuxChoco.addIngredient(new Ingredient(30, " g de beurre"));
		moelleuxChoco.addIngredient(new Ingredient(1, " oeuf"));
		moelleuxChoco.addEtape(new Etape("Faire fondre le chocolat.","chocolat"));
		moelleuxChoco.addEtape(
				new Etape("Ajouter le beurre en morceaux peu à peu et l'incorporer pour obtenir un crème bien lisse.","beurre"));
		moelleuxChoco.addEtape(new Etape(
				"Mettre la farine et le sucre glace dans un saladier. Ajouter les oeufs entiers et mélanger jusqu'à obtention d'une émulsion homogène.",new String[]{"farine","sucre glace","oeufs"}));
		moelleuxChoco.addEtape(new Etape("Verser le mélange chocolat-beurre sur cette préparation. Mélanger.","verseChoco"));
		moelleuxChoco.addEtape(new Etape("Beurrer et fariner 6 moules individuels ou un grand moule.","moule beurre"));
		moelleuxChoco.addEtape(new Etape(
				"Verser la préparation et mettre à four chaud (200°C) - 10 min pour les petits gâteaux, 15 pour le grand.","four"));
		moelleuxChoco.addEtape(new Etape(
				"Servir tiède avec une crème anglaise (le centre doit être coulant) ou servir froid nappé de ganache au chocolat.","moelleuxChoco"));
		try {
			moelleuxChoco.setImage("moelleux");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		listeRecettes.add(moelleuxChoco);
	}

	private void recette4_4() {
		Recette quatre = new Recette();
		quatre.setNom("Quatre-quarts");
		quatre.addIngredient(new Ingredient(30, " g de beurre "));
		quatre.addIngredient(new Ingredient(30, " g de sucre"));
		quatre.addIngredient(new Ingredient(35, " g de farine"));
		quatre.addIngredient(new Ingredient(1, " C.c levure"));
		quatre.addIngredient(new Ingredient(1, " oeuf(s)"));

		quatre.addEtape(
				new Etape("Préchauffez votre four à 180°C. Faites fondre le beurre 30 secondes au micro-ondes.","four"));
		quatre.addEtape(new Etape("Mélangez le beurre avec le sucre. Incorporez-y petit à petit les oeufs.",new String[]{"beurre","sucre","oeufs"}));
		quatre.addEtape(new Etape(
				"Une fois ce mélange effectué, ajoutez petit à petit la farine. Attention : faites-le par petite quantité pour éviter les grumeaux.","farine"));
		quatre.addEtape(new Etape(
				"Après la farine, incorporez la levure en poudre. Mélangez jusqu'à l'obtention d'un mélange parfait.","levure"));
		quatre.addEtape(new Etape(
				"Beurrez votre moule, versez-y la pâte et mettez le tout au four. Commencez à surveiller après 40 minutes de cuisson. Tant que le cake ne noircit pas, vous pouvez le laisser au four. Après 60 minutes maximum, le cake est à coup sûr somptueux.", new String[]{"moule beurre","four"}));
		try {
			quatre.setImage("quatre");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		listeRecettes.add(quatre);
	}

	private void recetteTiramissu()  {
		Recette tiram = new Recette();
		tiram.setNom("Tiramisu");
		tiram.addIngredient(new Ingredient(25, " g de sucre roux"));
		tiram.addIngredient(new Ingredient(65, " g de mascarpone"));
		tiram.addIngredient(new Ingredient(10, " cl de café noir"));
		tiram.addIngredient(new Ingredient(6, " boudoir"));
		tiram.addIngredient(new Ingredient(1, " oeuf(s)"));
		tiram.addIngredient(new Ingredient(1, " C.c cacao en poudre"));

		tiram.addEtape(new Etape("Séparer les blancs des jaunes d'oeufs", "oeufs"));
		tiram.addEtape(new Etape("Mélanger les jaunes avec le sucre roux ", new String[]{"oeufs","sucre roux"}));
		tiram.addEtape(new Etape("Ajouter le mascarpone au fouet","mascarpone"));
		tiram.addEtape(new Etape(
				"Monter les blancs en neige et les incorporer délicatement à la spatule au mélange précédent. Réserver","oeufs en neige"));
		tiram.addEtape(new Etape("Mouiller les biscuits dans le café rapidement avant d'en tapisser le fond du plat","cafe"));
		tiram.addEtape(new Etape(
				"Recouvrir d'une couche de crème au mascarpone puis répéter l'opération en alternant couche de biscuits et couche de crème en terminant par cette dernière ","mascarpone"));
		tiram.addEtape(new Etape("Saupoudrer de cacao","cacao"));
		tiram.addEtape(new Etape("Mettre au réfrigérateur 4 heures minimum puis déguster frais","frigo"));
		try {
			tiram.setImage("tiram");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		listeRecettes.add(tiram);
	}

	private void recetteCrumble()  {
		Recette crumble = new Recette();
		crumble.setNom("Crumble");
		crumble.addIngredient(new Ingredient(1, " petite pomme "));
		crumble.addIngredient(new Ingredient(20, " g de sucre"));
		crumble.addIngredient(new Ingredient(25, " g de farine"));
		crumble.addIngredient(new Ingredient(12, " g de beurre"));

		crumble.addEtape(
				new Etape("Préchauffer le four à 180°C (thermostat 6). Peler les pommes (ou les poires) et les Couper en dés",new String[]{"four","pommepoire"}));
		crumble.addEtape(new Etape("Dans un saladier, mélanger la farine au sucre puis du beurre",new String[]{"farine","sucre","beurre"}));
		crumble.addEtape(new Etape("Malaxer le tout avec les doigts pour obtenir une pâte sableuse","doigts"));
		crumble.addEtape(new Etape(
				"Beurrer le moule, y disposer les pommes tranchées (ou les poires) et placer la pâte par dessus.",new String[]{"moule beurre","pommepoire"}));
		crumble.addEtape(new Etape("Mélangez le beurre avec le sucre. Incorporez-y petit à petit les oeufs.",new String[]{"beurre","sucre","oeufs"}));
		crumble.addEtape(new Etape("Laisser cuire 25 min.. C'est prêt !","four"));
		try {
			crumble.setImage("crumble");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		listeRecettes.add(crumble);
	}

	private void recetteCookies() {
		Recette cookies = new Recette();
		cookies.setNom("Cookies");
		cookies.addIngredient(new Ingredient(20, " g de beurre "));
		cookies.addIngredient(new Ingredient(35, " g de farine"));
		cookies.addIngredient(new Ingredient(20, " beurre"));
		cookies.addIngredient(new Ingredient(1, " pincée de levure"));
		cookies.addIngredient(new Ingredient(1, " pincée de sel"));
		cookies.addIngredient(new Ingredient(25, " g de chocolat noir"));
		cookies.addIngredient(new Ingredient(1, " oeuf(s)"));

		cookies.addEtape(new Etape("Détailler le chocolat en pépites", "chocolat"));
		cookies.addEtape(new Etape(
				"Préchauffer le four à 180°C (thermostat 6). ","four"));
		cookies.addEtape(new Etape(
				"Dans un saladier, mettre la moitié du beurre, le sucre, l'oeuf entier et mélanger le tout.",new String[]{"beurre", "sucre", "oeufs", }));
		
		cookies.addEtape(new Etape("Ajouter petit à petit la farine , le sel et le chocolat",new String[]{"farine", "sel", "chocolat"}));
		cookies.addEtape(new Etape("Incorporez en suite la vanille et la levure",new String[]{"vanille", "levure"}));
		cookies.addEtape(new Etape(
				"Beurrer une plaque allant au four et former les cookies sur la plaque, Pour former les cookies, utiliser 2 cuillères à soupe et faire des petits tas espacés les uns des autres; ils grandiront à la cuisson.","moule beurre"));
		cookies.addEtape(new Etape("Enfourner pour 10 minutes de cuisson","four"));
		try {
			cookies.setImage("cookies");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		listeRecettes.add(cookies);
	}

	private void iniRecetteDuJour() {
		int taille = listeRecettes.size();
		int idRecette = (int) (Math.random() * (taille));
		// int nombreAleatoire = Min + (int)(Math.random() * ((Max - Min) + 1));
		recetteDuJour = listeRecettes.get(idRecette);
	}

	public LinkedList<Recette> getListeRecettes() {
		return listeRecettes;
	}

	public Recette getRecetteDuJour() {
		return recetteDuJour;
	}
}
