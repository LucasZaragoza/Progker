package recette;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.LinkedList;

import javafx.scene.image.Image;

public class Recette {
	private LinkedList<Ingredient> ingredients = new LinkedList<Ingredient>();
	private LinkedList<Etape> listeEtapes = new LinkedList<Etape>();
	private String nom;
	private Image image;

	public void addIngredient(Ingredient ingr) {
		ingredients.add(ingr);
	}

	public void setImage(String img) throws FileNotFoundException {
		String nomFichier = "src/main/resources/images/recettes/" + img + ".jpg";
		this.image = new Image(new FileInputStream(nomFichier));
	}

	public void addEtape(Etape etape) {
		listeEtapes.add(etape);
	}

	public LinkedList<Ingredient> getIngredients() {
		return ingredients;
	}

	public LinkedList<Etape> getListeEtapes() {
		return listeEtapes;
	}

	public String getNom() {
		return nom;
	}

	public Image getImage() {
		return image;
	}

	public void setIngredients(LinkedList<Ingredient> ingredients) {
		this.ingredients = ingredients;
	}

	public void setNom(String s) {
		this.nom = s;
	}

}
