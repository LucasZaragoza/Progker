package recette;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class Apprenant {

	private String nomString;
	private static LinkedList<Double> histoNiveau = new LinkedList<Double>();
	private static double niveau;

	public Apprenant() { // on peuple l'historique de données
		String nomFichier = "src/main/resources/bdd/historique.txt";
		File file = new File(nomFichier);
		FileReader fr;
		try {
			fr = new FileReader(file);
			try (BufferedReader br = new BufferedReader(fr)) {
				String line;
				while ((line = br.readLine()) != null) {
					histoNiveau.add(Double.parseDouble(line));
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		niveau = histoNiveau.getLast();
		
	}

	public String getNomString() {
		return nomString;
	}

	public void setNomString(String nomString) {
		this.nomString = nomString;
	}

	public static int getNiveau() {
		return (int) niveau;
	}

	public static void setNiveau(int niveau) {
		Apprenant.niveau = niveau;
	}

	public static void majApprenant(double score) {
		if (score > 0.33) {
			score /= 2; // apprenant a besoin de 2 100% pour lvl up
			niveau += score;
		} else {
			niveau -= 0.5;
			if (niveau < 0)
				niveau = 0;
		}
		String nomFichier = "src/main/resources/bdd/historique.txt";
		try {
			try (BufferedWriter sortie = new BufferedWriter(new FileWriter(nomFichier, true))) {
				sortie.write(niveau + "\n");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		histoNiveau.add(niveau);
		
	}

	public static void useIndice() {
		niveau -= 0.2;
		if (niveau < 0)
			niveau = 0;
	}

	public static List<Double> getHistoNiveau() {
		return histoNiveau;
	}

}
