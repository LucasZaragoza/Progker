package org.openjfx.addfx;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Series;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import recette.Apprenant;

public class ResultatsController {

	@FXML
	private Pane resultatsPane;
	@FXML
	private Pane retour;

	@FXML
	private Label titre;

	@FXML
	private Text niveau0;
	@FXML
	private Text niveau1;
	@FXML
	private Text niveau2;
	@FXML
	private Text niveau3;
	@FXML
	private Text niveau4;
	@FXML
	private Text niveau5;
	@FXML
	private Text niveau6;

	@FXML
	protected void initialize() throws IOException {
		// add graphe d'histo des resultats a resultats Pane

		// defining the axes
		final NumberAxis xAxis = new NumberAxis();
		final NumberAxis yAxis = new NumberAxis();
		xAxis.setLabel("Les repas qui passent");
		yAxis.setLabel("Mes scores");
		// creating the chart
		LineChart<Number, Number> resultChart = new LineChart<Number, Number>(xAxis, yAxis);

		// defining a series
		final Series<Number, Number> series = new XYChart.Series<Number, Number>();
		// populating the series with data
		for (int i = 0; i < Apprenant.getHistoNiveau().size(); i++) {
			series.getData().add(new XYChart.Data(i, Apprenant.getHistoNiveau().get(i)));
		}
		resultChart.setLegendVisible(false);
		resultChart.getData().add(series);
		resultChart.setPrefSize(500, 450);
		;
		resultatsPane.getChildren().add(resultChart);
		titre.setText("	Historique de tes résultats.  Tu es au niveau " + Apprenant.getNiveau() + " !");

		iniNiveau();

	}

	private void iniNiveau() {
		double scoreLvl0 = 0;
		double totLvl0 = 0;
		double scoreLvl1 = 0;
		double totLvl1 = 0;
		double scoreLvl2 = 0;
		double totLvl2 = 0;
		double scoreLvl3 = 0;
		double totLvl3 = 0;
		double scoreLvl4 = 0;
		double totLvl4 = 0;
		double scoreLvl5 = 0;
		double totLvl5 = 0;
		double scoreLvl6 = 0;
		double totLvl6 = 0;
		
		String nomFichier = "src/main/resources/bdd/historiqueNvx.txt";
		File file = new File(nomFichier);
		FileReader fr;
		try {
			fr = new FileReader(file);
			try (BufferedReader br = new BufferedReader(fr)) {
				String line;
				while ((line = br.readLine()) != null) {
					
					String [] res = line.split("/");
					switch(res[1]) {
					case "0":
						totLvl0 += 1;
						scoreLvl0 += Integer.parseInt(res[0]);
						break;
					case "1":
						totLvl1 += 1;
						scoreLvl1 += Integer.parseInt(res[0]);
						break;
					case "2":
						totLvl2 += 1;
						scoreLvl2 += Integer.parseInt(res[0]);
						break;
					case "3":
						totLvl3 += 1;
						scoreLvl3 += Integer.parseInt(res[0]);
						break;
					case "4":
						totLvl4 += 1;
						scoreLvl4 += Integer.parseInt(res[0]);
						break;
					case "5":
						totLvl5 += 1;
						scoreLvl5 += Integer.parseInt(res[0]);
						break;
					case "6":
						totLvl6 += 1;
						scoreLvl6 += Integer.parseInt(res[0]);
						break;
					}				
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		String reu = "Taux de réussite au niveau ";
		if (totLvl0 != 0) {
			niveau0.setVisible(true);
			niveau0.setText(reu + " 0 = " + (int)((scoreLvl0/totLvl0)*100) + "%");
		}
		else 
			niveau0.setVisible(false);
		
		if (totLvl1 != 0) {
			niveau1.setVisible(true);
			niveau1.setText(reu + " 1 = " + (int)((scoreLvl1/totLvl1)*100) + "%");
		}
		else 
			niveau1.setVisible(false);
		
		if (totLvl2 != 0) {
			niveau2.setVisible(true);
			niveau2.setText(reu + " 2 = " + (int)((scoreLvl2/totLvl2)*100) + "%");
		}
		else 
			niveau2.setVisible(false);
		
		if (totLvl3 != 0) {
			niveau3.setVisible(true);
			niveau3.setText(reu + " 3 = " + (int)((scoreLvl3/totLvl3)*100) + "%");
		}
		else 
			niveau3.setVisible(false);
		
		if (totLvl4 != 0) {
			niveau4.setVisible(true);
			niveau4.setText(reu + " 4 = " + (int)((scoreLvl4/totLvl4)*100) + "%");
		}
		else 
			niveau4.setVisible(false);
		
		if (totLvl5 != 0) {
			niveau5.setVisible(true);
			niveau5.setText(reu + " 5 = " + (int)((scoreLvl5/totLvl5)*100) + "%");
		}
		else 
			niveau5.setVisible(false);
		
		if (totLvl6 != 0) {
			niveau6.setVisible(true);
			niveau6.setText(reu + " 6 = " + (int)((scoreLvl6/totLvl6)*100) + "%");
		}
		else 
			niveau6.setVisible(false);
	}

	@FXML
	private void switchToPrimary() throws IOException {
		App.setRoot("primary");
	}

}
