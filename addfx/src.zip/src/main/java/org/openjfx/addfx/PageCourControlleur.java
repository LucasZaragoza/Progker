package org.openjfx.addfx;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;


import javafx.fxml.FXML;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import recette.Apprenant;

public class PageCourControlleur {
	@FXML
	AnchorPane image;

	@FXML
	protected void initialize() throws FileNotFoundException {
		String nomFichier = "src/main/resources/images/cours/" + Integer.toString(CourController.getCoursChoisis()) + ".png";
		Image i = new Image(new FileInputStream(nomFichier));
		ImageView iv = new ImageView(i);
		iv.setX(45);
		iv.setY(25);
		iv.setFitHeight(470);
		iv.setFitWidth(800-70);
	    DropShadow ds = new DropShadow( 10, Color.BLACK );
        iv.setEffect( ds );


		image.getChildren().add(iv);
		if (CourController.getCoursChoisis() == 0) {

		}
	}

	@FXML
	private void retourMenu() throws IOException {
		App.setRoot("cours");
	}

}
