package org.openjfx.addfx;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class CourController {
	private static int coursChoisi = 0;
	
	public static int getCoursChoisis() {
		return coursChoisi;
	}
	

	@FXML
	private Button courAddition;

	@FXML
	private Button courSoustraction;

	@FXML
	private Button courMultiplication;

	@FXML
	private Button courDivision;

	@FXML
	private void retour() throws IOException {
		App.setRoot("primary");
	}


	@FXML
	private void courSoustraction() throws IOException {
		coursChoisi = 1;
		App.setRoot("pageCour");
	}

	@FXML
	private void courMultiplication() throws IOException {
		coursChoisi = 2;
		App.setRoot("pageCour");
	}

	@FXML
	private void courDivision() throws IOException {
		coursChoisi = 4;
		App.setRoot("pageCour");
	}

	@FXML
	private void courAddition() throws IOException {
		coursChoisi = 0;
		App.setRoot("pageCour");
	}
	
	@FXML
	private void courOrdreDePrio() throws IOException {
		coursChoisi = 4;	
		App.setRoot("pageCour");
	}
	

}
