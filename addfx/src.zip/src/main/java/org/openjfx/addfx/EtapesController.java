package org.openjfx.addfx;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.LinkedList;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import recette.Recette;

public class EtapesController {

	private Recette recetteDuJour;

	@FXML
	private Label desc;
	@FXML
	private Label titre;
	@FXML
	private Button prev;
	@FXML
	private Button next;
	
	@FXML
	private ImageView iv;
	
	@FXML
	private ImageView iv1;
	
	@FXML
	private ImageView iv2;
	
	@FXML
	private ImageView iv3;
	public LinkedList<ImageView> list = new LinkedList<ImageView>();


	@FXML
	protected void initialize() throws IOException {
		// recuperer recetteDuJour
		recetteDuJour = PrimaryController.getRecetteChoisie();
		desc.setWrapText(true);
		String nomFichier = "src/main/resources/images/etapes/papier.jpg";
		Image image = new Image(new FileInputStream(nomFichier),370,455,false,false);
		iv.setImage(image);
		list.add(iv1);
		list.add(iv2);
		list.add(iv3);
		etapeSuivante(1);
	}

	protected void etapeSuivante(int numEtape) throws IOException {

		// description et image etape
		iv1.setImage(null);
		iv2.setImage(null);
		iv3.setImage(null);
		titre.setText("Etape " + numEtape);
		desc.setText(recetteDuJour.getListeEtapes().get(numEtape - 1).getDescr());

		String[] nomsImage = recetteDuJour.getListeEtapes().get(numEtape - 1).getImg();
		for (int i = 0; i < nomsImage.length; i++) {
			//groupes de 2
			String nomFichier = "src/main/resources/images/etapes/" + nomsImage[i] + ".jpg";
			Image image = new Image(new FileInputStream(nomFichier));
			String imv = "iv"+i+1;
			list.get(i).setImage(image);
		   // DropShadow ds = new DropShadow( 10, Color.BLACK );
		    //list.get(i).setEffect( ds );
		//	imVvvv.setFitWidth(150/nomsImage.length);
			//imVvvv.setFitHeight(150/nomsImage.length);			
		}
		

		next.setText("Etape suivante");
		// next.setWrapText(true);

		if (numEtape == recetteDuJour.getListeEtapes().size()) {
			// On est arrive a la fin des etapes et bouton pour revenir ecran principal
			prev.setVisible(true);
			next.setText("Recette finie, retour au menu principal");
			next.setOnAction(event -> {
				try {
					switchToPrimary();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});
			final int etapepre = numEtape - 1;
			prev.setOnAction(event -> {
				try {
					if (etapepre > 0)
						etapeSuivante(etapepre);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});
		} else {
			if (numEtape == 1) {
				numEtape++;
				final int etapeSu = numEtape;
				final int etapepre = numEtape - 2;
				next.setOnAction(event -> {
					try {
						etapeSuivante(etapeSu);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				});
				prev.setVisible(false);
			}
			else {
				numEtape++;
				final int etapeSu = numEtape;
				final int etapepre = numEtape - 2;
				prev.setVisible(true);
				next.setOnAction(event -> {
					try {
						etapeSuivante(etapeSu);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				});
				prev.setOnAction(event -> {
					try {
						if (etapepre > 0)
							etapeSuivante(etapepre);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				});
			}
		}
	}

	@FXML
	private void switchToPrimary() throws IOException {
		App.setRoot("primary");
	}

}
