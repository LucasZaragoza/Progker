package org.openjfx.addfx;

import java.io.IOException;
import java.util.LinkedList;


import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import recette.Recette;

public class ToutesRecettesController {

	@FXML
	private Pane paneRecettes;

	@FXML
	protected void initialize() throws IOException {
		
		int layoutX = 10;
		int layoutY = 10;

		LinkedList<Recette> listeRecettes = PrimaryController.bddR.getListeRecettes();

		for (int i = 0; i < listeRecettes.size(); i++) {
			layoutY = i / 3 * (int)(App.getScene().getHeight()-70 ) / 3 + 30 ; 
			layoutX = (i % 3) * (int)App.getScene().getWidth() / 3 + 60 ;
			Button b = new Button();
			final Recette recette = listeRecettes.get(i);
			b.setOnAction(event -> {
				PrimaryController.setRecetteChoisie(recette);
				try {
					switchToRecette();
				} catch (IOException e) {
					e.printStackTrace();
				}
			});
			b.setText(listeRecettes.get(i).getNom());
			b.setLayoutX(layoutX);
			b.setPrefWidth (150);
			b.setLayoutY(layoutY+100);
			b.setId("boutonNorm");

			paneRecettes.getChildren().add(b);

			ImageView imageView = new ImageView(PrimaryController.bddR.getListeRecettes().get(i).getImage());
			imageView.setFitHeight(90);
			imageView.setFitWidth(150);
			imageView.setLayoutX(layoutX);
			imageView.setLayoutY(layoutY);
		    DropShadow ds = new DropShadow( 10, Color.BLACK );
		    imageView.setEffect( ds );
			paneRecettes.getChildren().add(imageView);

			// paneRecettes.getChildren().add(hb);
		}
	}

	@FXML
	private void switchToPrimary() throws IOException {
		App.setRoot("primary");
	}

	@FXML
	private void switchToRecette() throws IOException {
		App.setRoot("recette");
	}

}
