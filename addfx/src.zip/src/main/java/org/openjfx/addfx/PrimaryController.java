package org.openjfx.addfx;

import java.io.IOException;
import java.util.LinkedList;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import recette.Apprenant;
import recette.BDDRecettes;
import recette.Recette;

public class PrimaryController  {
	
	private static Recette recetteChoisie;
    public static BDDRecettes bddR = new BDDRecettes();
    private static Apprenant a = new Apprenant();
    
    @FXML
    private TextField niveauStp;
    
    @FXML
    private void switchToRecetteJour() throws IOException {
    	recetteChoisie = bddR.getRecetteDuJour();
        App.setRoot("recette");
    } 
    @FXML
    private void switchToCours() throws IOException {
        App.setRoot("cours");
    }
    
    @FXML
    private void switchToResultats() throws IOException {
        App.setRoot("resultats");
    }
    
    @FXML
    private void switchToToutesRecettes() throws IOException {
        App.setRoot("toutesRecettes");
    }

    @FXML
    private void updateNiveau() {
    	Apprenant.setNiveau(Integer.parseInt(niveauStp.getText()));
    }
    
	public static Recette getRecetteChoisie() {
		return recetteChoisie;
	}

	public static void setRecetteChoisie(Recette recette) {
		recetteChoisie = recette;
	}
}
