package org.openjfx.addfx;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import recette.Apprenant;
import recette.Calcul;
import recette.Ingredient;
import recette.Recette;

public class RecetteController {

	public int resultat = 0;
	public int nberreur = 0;
	public int nbPersonne = 0;
	private static boolean pasDeVide;
	private static boolean aRepondu; // booleen pour update le profil de l'apprenant a la premiere reponse
	private static LinkedList<Float> resultAtt = new LinkedList<Float>();
	private static LinkedList<Float> reponses = new LinkedList<Float>();

	@FXML
	private AnchorPane mainAnchorPane;
	@FXML
	private AnchorPane recetteExemple;

	private int niveau = Apprenant.getNiveau();
	@FXML
	private Text nomRecette;

	@FXML
	private AnchorPane imV;

	@FXML
	private AnchorPane descRecette;
	@FXML
	private HBox boxNbPersonnes;
	@FXML
	private TextField saisieNbPersonnes;
	@FXML
	private Button verifierRecette;
	@FXML
	private Text textNbPersonnes;
	@FXML
	private Text textVerifier;
	@FXML
	private Text recetteGG;

	@FXML
	private Button valideNbPersonnes;

	@FXML
	private Button BoutonIndice;

	@FXML
	private AnchorPane allonsCuisiner;

	private Recette recetteChoisie = PrimaryController.getRecetteChoisie();

	@FXML
	protected void initialize() {

		aRepondu = false;
		nomRecette.setText(recetteChoisie.getNom());
		nomRecette.wrappingWidthProperty();

		ImageView imageV = new ImageView();
		Image image = recetteChoisie.getImage();
		imageV.setImage(image);
		imV.getChildren().add(imageV);
		DropShadow ds = new DropShadow(10, Color.BLACK);
		imV.setEffect(ds);

		imageV.setFitWidth(350);
		imageV.setFitHeight(200);

		BoutonIndice.setVisible(false);
		BoutonIndice.setDisable(true);

		verifierRecette.setVisible(false);

		saisieNbPersonnes.textProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
				if (!newValue.matches("\\d*")) {
					saisieNbPersonnes.setText(newValue.replaceAll("[^\\d]", ""));
				}
			}
		});
	}

	@FXML
	private void validerNbPersonnes() {
		try {
			int nbPers = Integer.parseInt(saisieNbPersonnes.getText());
			if (nbPers < 31 && 0 < nbPers) {
				textNbPersonnes.setText("Pour " + nbPers + " personnes");
				boxNbPersonnes.getChildren().remove(saisieNbPersonnes);
				boxNbPersonnes.getChildren().remove(valideNbPersonnes);
				nbPersonne = nbPers;
				genererRecette(nbPers);
			} else {
				textNbPersonnes.setText("Saisir un nbre entre 1 et 30");
			}
		} catch (Exception e) {
			textNbPersonnes.setText("Saisir un nbre entre 1 et 30");
		}
	}

	@FXML
	private void afficheIndice() throws IOException {
		final Stage dialog = new Stage();
		AnchorPane a = new AnchorPane();
		// a.setId("pane");
		a.setPrefSize(600, 350);
		dialog.initModality(Modality.APPLICATION_MODAL);

		VBox dialogVbox = new VBox(20);
		a.setBackground(
				new Background(new BackgroundFill(Color.rgb(128, 255, 92, 0.6), CornerRadii.EMPTY, Insets.EMPTY)));
		Text tt = new Text("Tu es au niveau : " + niveau);
		tt.setFont(Font.font("Segoe Print", 10));
		dialogVbox.getChildren().add(tt);
		for (int i = 0; i < reponses.size(); i++) {
			String calcul = ((Label) (descRecette.getChildren().get(i * 3))).getText();
			if (reponses.get(i) < 0) {
				dialogVbox.getChildren().add(
						new Text("La réponse est VIDE pour le calcul " + calcul.substring(0, calcul.length() - 2)));
			} else {
				if (reponses.get(i) > resultAtt.get(i)) {
					Text t = new Text("La réponse attendue est inférieure pour le calcul "
							+ calcul.substring(0, calcul.length() - 2));
					t.setFont(Font.font("Segoe Print", 10));

					dialogVbox.getChildren().add(t);
				}
				if (reponses.get(i) < resultAtt.get(i)) {
					Text t = new Text("La réponse attendue est supérieure pour le calcul "
							+ calcul.substring(0, calcul.length() - 2));
					t.setFont(Font.font("Segoe Print", 10));
					dialogVbox.getChildren().add(t);
				}
			}
		}
		if (niveau < 4) {
			String nomFichier = "src/main/resources/images/indice/" + niveau + ".png";
			Image image = new Image(new FileInputStream(nomFichier));
			ImageView imageView = new ImageView(image);
			DropShadow ds = new DropShadow(10, Color.AQUA);
			imageView.setEffect(ds);
			imageView.setX(350);
			imageView.setY(10);
			imageView.setFitHeight(300);
			imageView.setFitWidth(200);
			a.getChildren().add(imageView);

		}
		a.getChildren().add(dialogVbox);
		Scene dialogScene = new Scene(a, 600, 350);
		dialog.setScene(dialogScene);
		dialog.show();
		Apprenant.useIndice();

	}

	private static Parent loadFXML(String fxml) throws IOException {
		FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml + ".fxml"));
		return fxmlLoader.load();
	}

	private void genererRecette(int nbPers) {

		verifierRecette.setVisible(true);

		int layout = 5;

		for (int i = 0; i < recetteChoisie.getIngredients().size(); i++) {
			layout += 30;

			Ingredient ingr = recetteChoisie.getIngredients().get(i);

			// label montre le calcul
			Label calcul = new Label();
			String aCalcul = Calcul.calcul(ingr.getQte(), nbPers, Apprenant.getNiveau(), i);
			calcul.setText(aCalcul + " = ");
			calcul.setLayoutX(10);
			calcul.setLayoutY(layout);
			calcul.setId("text");

			// hb.getChildren().add(calcul);

			// rep apprenant
			TextField tf = new TextField();
			tf.setPrefWidth(40);
			tf.setLayoutX(190);
			tf.setLayoutY(layout);
			tf.textProperty().addListener(new ChangeListener<String>() {
				@Override
				public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
					if (!newValue.matches("\\d*")) {
						tf.setText(newValue.replaceAll("[^\\d]", ""));
					}
				}
			});

			Label lab = new Label();
			lab.setText(ingr.getDescription());
			lab.setLayoutX(250);
			lab.setLayoutY(layout);
			lab.setId("text");

			// hb.getChildren().add(lab);

			descRecette.getChildren().add(calcul);
			descRecette.getChildren().add(tf);
			descRecette.getChildren().add(lab);
		}

	}

	/**
	 * Lorsqu'on clique sur le bouton pour vérifier les réponses de l'apprenant
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@FXML
	private void verifierRecette() {
		textVerifier.setVisible(true);
		if (reponsesOk()) { // s'il a bien répondu on lui donne un bouton pour passer a l'étape d'après
			verifierRecette.setVisible(false);
			textVerifier.setVisible(false);
			BoutonIndice.setVisible(false);
			recetteGG.setVisible(true);
			recetteGG.setText("Bien joué! Tu peux passer à la cuisine");
			Button b = new Button();
			b.setText("Allons cuisiner !");
			b.setId("valider");
			b.setLayoutX(36);
			b.setLayoutY(54);
			b.setPrefSize(174, 58);
			// b.setWrapText(true);
			b.setOnAction(new EventHandler() {
				@Override
				public void handle(Event event) {
					try {
						switchToEtapes();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			});
			allonsCuisiner.getChildren().add(b);
		} else {
			if (pasDeVide)
				textVerifier.setText("Tu as commis une erreur, tu dois réessayer ");
			nberreur++;
			if (nberreur > 1) {
				BoutonIndice.setVisible(true);
				BoutonIndice.setDisable(false);
			}
		}
	}

	private boolean reponsesOk() {
		int reopOK = 0;
		reponses = new LinkedList<Float>();
		boolean pasDerreur = true;
		pasDeVide = true;
		// on renvoie une note en %
		float score = 0;
		for (int i = 0; i < descRecette.getChildren().size() / 3; i++) {
			float resAtt = recetteChoisie.getIngredients().get(i).getQte() * nbPersonne;
			TextField tb = (TextField) (descRecette.getChildren().get(i * 3 + 1));
			if (tb.getText().length() > 0) {
				float resEnt = Float.parseFloat(tb.getText());
				reponses.add(resEnt);
				resultAtt.add(resAtt);
				if (resAtt != resEnt) {
					tb.setBorder(new Border(new BorderStroke(Color.RED, BorderStrokeStyle.SOLID, null, null)));
					reopOK = 0;
					pasDerreur = false;
				} else {
					tb.setBorder(new Border(new BorderStroke(Color.GREEN, BorderStrokeStyle.SOLID, null, null)));
					reopOK = 1;
					score += 1;
				}
				if (!aRepondu) {
					modifFile(reopOK);
				}
			} else {
				tb.setBorder(new Border(new BorderStroke(Color.RED, BorderStrokeStyle.SOLID, null, null)));
				pasDerreur = false;
				pasDeVide = false;
				textVerifier.setText("Merci de remplir tous les champs");
				reponses.add((float) -1);
				resultAtt.add(resAtt);
			}
		}
		if (!aRepondu) {
			// si c est la premiere reponse de l'apprenant
			score = score / (descRecette.getChildren().size() / 3); // on transforme le score en %
			Apprenant.majApprenant(score);
		}

		aRepondu = true;
		return pasDerreur;
	}

	private void modifFile(int reopOK) {
		String nomFichier = "src/main/resources/bdd/historiqueNvx.txt";
		try {
			try (BufferedWriter sortie = new BufferedWriter(new FileWriter(nomFichier, true))) {
				sortie.write("\n"+reopOK + "/" + niveau);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} 
	}

	@FXML
	private void switchToEtapes() throws IOException {
		App.setRoot("etapes");
	}

	@FXML
	private void switchToPrimary() throws IOException {
		App.setRoot("primary");
	}

}
