package snippet;

public class Snippet {
	Image image = new Image(new FileInputStream("ressources/maison.jpg"));
	
}

